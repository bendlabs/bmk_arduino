#ifndef __GUI_H__
#define __GUI_H__

#ifndef _WIN32

int gui_init(const char *ttyname);

#endif /* _WIN32 */

#endif
