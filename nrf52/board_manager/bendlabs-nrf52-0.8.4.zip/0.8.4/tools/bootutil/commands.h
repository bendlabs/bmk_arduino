#ifndef __COMMANDS_H__
#define __COMMANDS_H__

int commands_cmd_reset(void);
int commands_parse(char *argv);

#endif
